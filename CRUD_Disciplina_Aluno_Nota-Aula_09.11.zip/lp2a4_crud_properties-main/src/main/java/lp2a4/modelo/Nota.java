package lp2a4.modelo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="notas")
public class Nota implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Id
	@Column
	private long idNota;
	@Column
	private int nota;
	
	@ManyToOne(targetEntity=AlunoPOJO.class)
	@JoinTable(
			  name = "notas_do_aluno", 
			  joinColumns = @JoinColumn(name = "matricula"), 
			  inverseJoinColumns = @JoinColumn(name = "idNota")
			)
	private AlunoPOJO aluno;

	@ManyToOne(targetEntity=Disciplina.class)
	@JoinTable(
			  name = "disciplinas_com_nota", 
			  joinColumns = @JoinColumn(name = "codigo"), 
			  inverseJoinColumns = @JoinColumn(name = "idNota"))
	private Disciplina disciplina;
   
}
