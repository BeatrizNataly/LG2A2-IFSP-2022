package lp2a4.controller;

public enum CommandEnum {
	CREATE ,
	RETRIEVE ,
	UPDATE,
	NAVIGATE_UPDATE,
	DELETE,
	DESCONHECIDO;
}
